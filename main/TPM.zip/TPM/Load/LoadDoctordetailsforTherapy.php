<?php
  
session_cache_limiter(FALSE);
session_start();
  
//insert.php
if(isset($_POST["DoctorCode"]))
{
  
 // echo "1";
 include("../../../connect.php"); 
  $currentdate =date("Y-m-d H:i:s"); 							  
 $DoctorCode = mysqli_real_escape_string($connection, $_POST["DoctorCode"]);

  
 $query=mysqli_query($connection, "
 SELECT doctorname,doctoremail,doctorphone
FROM doctormaster WHERE doctorcode ='".$DoctorCode."'");
 
	 
	 $data = array();
   
    while($row=mysqli_fetch_assoc($query))
    { 
     
      $data[] = $row['doctorname']; 
	   $data[] = $row['doctoremail']; 
	    $data[] = $row['doctorphone'];  
    }
	  
echo json_encode($data);
 
  
    mysqli_close($connection);

  
}

?>