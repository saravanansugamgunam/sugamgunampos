<?php
  
session_cache_limiter(FALSE);
session_start();
  
//insert.php
if(isset($_POST["BookingID"]))
{
	 date_default_timezone_set("Asia/Kolkata");
   
 // echo "1";
 include("../../../connect.php"); 
	   
  $currentdate =date("Y-m-d");  
   $currenttime = date("His");
	    
	   
 $BookingID = mysqli_real_escape_string($connection, $_POST["BookingID"]);    
 $NextSittingDate = mysqli_real_escape_string($connection, $_POST["NextSittingDate"]);   
 $NextSittingTime = mysqli_real_escape_string($connection, $_POST["NextSittingTime"]);    
 $Comments = mysqli_real_escape_string($connection, $_POST["Comments"]);    
 $BalanceSitting = mysqli_real_escape_string($connection, $_POST["BalanceSitting"]);  
 $Sittingid = mysqli_real_escape_string($connection, $_POST["SittingID"]);  
 
   
    
 $LocationCode = $_SESSION['SESS_LOCATION'];
  // $ClientID = $_SESSION["CMS_CompanyID"];
  // $userid = $_SESSION["CMS_EmployeeID"];
  $ClientID = 1;
  $userid = 1;	
  $CurrentTime =date("h:i:s");
   
  
  try {
	  
	  
	  
  
  if( $BalanceSitting==1 || $BalanceSitting==0 )
  {
	  
	    $SaveSaleMaster="  UPDATE therapybookingdetails SET bookingstatus='Closed',sittingdate='$currentdate',STATUS=1, 
		closureremarks='$Comments' WHERE sitingid = '$Sittingid' AND bookinguniqueid ='$BookingID';";

       // $SaveSaleMaster.=" UPDATE therapybookingdetails set bookingstatus='Closed',closingdate='$currentdate' where bookinguniqueid ='$BookingID';"; 
		 
		$SaveSaleMaster.=" UPDATE therapybookingmaster set therapystatus='Closed',closingdate='$currentdate' where bookinguniqueid ='$BookingID';"; 
		
		 $SaveSaleMaster.= "insert into therapyclosredetails (bookinguniqueid,therapyid,paitentid,sitting,closingdate,updatedby) 
		 SELECT bookinguniqueid,therapyid,paitentid,sitingid,'$currentdate',1 FROM therapybookingdetails WHERE bookinguniqueid ='$BookingID' and sitingid = '$Sittingid' ;"; 
	
	
  }
  else if( $BalanceSitting > 1)
  {
	  
		// $SaveSaleMaster=" UPDATE therapybookingdetails set reviseddate='$NextSittingDate',revisedtime='$NextSittingTime' where bookinguniqueid ='$BookingID';"; 
		
			  
	    $SaveSaleMaster="  UPDATE therapybookingdetails SET bookingstatus='Closed',sittingdate='$currentdate',STATUS=1, 
closureremarks='$Comments',revisedtime='$CurrentTime' WHERE sitingid = '$Sittingid' AND bookinguniqueid ='$BookingID';";

if($NextSittingDate<>'')
{
	$SaveSaleMaster.="UPDATE therapybookingdetails SET  nextsettingdate='$NextSittingDate'  WHERE  
	 sitingid = '$Sittingid'+1 AND bookinguniqueid ='$BookingID';";

$SaveSaleMaster.=" UPDATE therapybookingmaster set  therapystatus='Scheduled',revisedtherapydate='$NextSittingDate',
revisedtherapytime='$NextSittingTime' where bookinguniqueid ='$BookingID';";
}  
else
{
  $SaveSaleMaster.=" UPDATE therapybookingmaster set  therapystatus='Booked'  where bookinguniqueid ='$BookingID';";
}
		  

		 $SaveSaleMaster.= "insert into therapyclosredetails (bookinguniqueid,therapyid,paitentid,sitting,closingdate,updatedby) 
		 SELECT bookinguniqueid,therapyid,paitentid,sitingid,'$currentdate',1 FROM therapybookingdetails WHERE bookinguniqueid ='$BookingID' and sitingid = '$Sittingid' ;"; 
  }
  
 
  if(mysqli_multi_query($connection, $SaveSaleMaster)){ 
      echo 1;
    // echo $SaveSaleMaster;
  } else{
    // echo "ERROR: Could not able to execute $AddItem. " . mysqli_error($connection);
    // echo "0";
    echo $SaveSaleMaster;
  }
   
     
} catch (Exception $e) {
   echo 'Message: ' .$e->getMessage();
}    
   
}
else
{
	echo "Error";
}

?>