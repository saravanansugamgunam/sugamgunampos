<!DOCTYPE html>
<!--[if IE 8]>
<html lang="en" class="ie8">
  <![endif]-->
<!--[if !IE]>
  <!-->
<html lang="en">
<!--
    	<![endif]-->
<?php 
  
    include("../../connect.php");
    // $position=$_SESSION["SESS_LAST_NAME"]; 
	 session_cache_limiter(FALSE);
    session_start();
  $LocationCode = $_SESSION['SESS_LOCATION'];
  $GroupID = $_SESSION['SESS_GROUP_ID'];
     if(isset($_SESSION['SESS_LAST_NAME']))
    {
    //echo 'Session Active';
    
    }
    else
    {
    //echo 'Session In Active';
    $url='../../index.php';
    echo '
    <META HTTP-EQUIV=REFRESH CONTENT=".1; '.$url.'">';
    }


    ?>

<head>
    <meta charset="utf-8" />
    <title>SugamGunam</title>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    <!-- ================== BEGIN BASE CSS STYLE ================== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <link href="../assets/plugins/jquery-ui/themes/base/minified/jquery-ui.min.css" rel="stylesheet" />
    <link href="../assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <link href="../assets/css/animate.min.css" rel="stylesheet" />
    <link href="../assets/css/style.min.css" rel="stylesheet" />
    <link href="../assets/css/style-responsive.min.css" rel="stylesheet" />
    <link href="../assets/css/theme/default.css" rel="stylesheet" id="theme" />
    <!-- ================== END BASE CSS STYLE ================== -->
    <!-- ================== BEGIN BASE JS ================== -->
    <link href="../assets/plugins/bootstrap-datepicker/css/datepicker.css" rel="stylesheet" />
    <link href="../assets/plugins/bootstrap-datepicker/css/datepicker3.css" rel="stylesheet" />
    <link href="../assets/plugins/ionRangeSlider/css/ion.rangeSlider.css" rel="stylesheet" />
    <link href="../assets/plugins/ionRangeSlider/css/ion.rangeSlider.skinNice.css" rel="stylesheet" />
    <link href="../assets/plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet" />
    <link href="../assets/plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css" rel="stylesheet" />
    <link href="../assets/plugins/password-indicator/css/password-indicator.css" rel="stylesheet" />
    <link href="../assets/plugins/bootstrap-combobox/css/bootstrap-combobox.css" rel="stylesheet" />
    <link href="../assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
    <link href="../assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet" />
    <link href="../assets/plugins/jquery-tag-it/css/jquery.tagit.css" rel="stylesheet" />
    <link href="../assets/plugins/bootstrap-daterangepicker/daterangepicker-bs3.css" rel="stylesheet" />
    <link href="../assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" />
    <link href="../assets/plugins/switchery/switchery.min.css" rel="stylesheet" />
    <link href="../assets/plugins/DataTables/css/data-table.css" rel="stylesheet" />
    <link href="../assets/css/theme/default.css" rel="stylesheet" id="theme" />
    <link href="../assets/plugins/bootstrap-wizard/css/bwizard.min.css" rel="stylesheet" />
    <script src="../assets/plugins/pace/pace.min.js"></script>
    <!-- ================== END BASE JS ================== -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <link href="../assets/Custom/sweetalert.css" rel="stylesheet" />
    <script src="../assets/Custom/sweetalert2.min.js"></script>
    <link href="style/style.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="../assets/Custom/masking-input.css" />

    <style>
    body {
        background: #f5f5f5 url('../assets/img/bg.png') left top repeat;
    }

    #f1_upload_process {
        z-index: 100;
        visibility: hidden;
        position: absolute;
        text-align: center;
        width: 400px;
    }

    .msg {
        text-align: left;
        color: #666;
        background-repeat: no-repeat;
        margin-left: 30px;
        margin-right: 30px;
        padding: 5px;
        padding-left: 30px;
    }

    .emsg {
        text-align: left;
        margin-left: 30px;
        margin-right: 30px;
        color: #666;
        background-repeat: no-repeat;
        padding: 5px;
        padding-left: 30px;
    }
    </style>

</head>

<body onload="LoadInvoiceNo();">
    <!-- begin #page-loader -->

    <!-- end #page-loader -->
    <!-- begin #page-container -->
    <div id="page-container" class="fade page-sidebar-minified page-header-fixed">
        <!-- begin #header -->
        <div id="header" class="header navbar navbar-default navbar-fixed-top">
            <!-- begin container-fluid -->
            <div class="container-fluid">
                <!-- begin mobile sidebar expand / collapse button -->
                <div class="navbar-header">
                    <a href="../index.php" class="navbar-brand">
                        <img src="../assets/img/logo.png" class="media-object" width="150" alt="" />
                    </a>
                    <button type="button" class="navbar-toggle" data-click="sidebar-toggled">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <!-- end mobile sidebar expand / collapse button -->
                <!-- begin header navigation right -->
                <ul class="nav navbar-nav navbar-right">

                    <li class="dropdown navbar-user">
                        <a href="javascript:;" data-toggle="dropdown" class="dropdown-toggle f-s-14">

                            <i class="fa fa-bell-o"></i>
                        </a>
                    </li>

                    <li class="dropdown navbar-user">
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
                            <img src="../assets/img/user-13.jpg" alt="" />
                            <span class="hidden-xs">
                                <?php echo $_SESSION['SESS_FIRST_NAME']; ?>
                            </span>

                        </a>
                    <li class="divider"></li>
                    <li>
                        <a href="../logout.php">Log Out</a>
                    </li>
                    <ul class="dropdown-menu animated fadeInLeft">
                        <li class="arrow"></li>
                        <li>
                            <a href="PasswordChange.php">Change Password</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="logout.php">Log Out</a>
                        </li>
                    </ul>
                    </li>
                </ul>
                <!-- end header navigation right -->
            </div>
            <!-- end container-fluid -->
        </div>
        <!-- end #header -->

        <div id="wait"
            style="display:none;width:69px;height:189px;border:1px grey;position:absolute;top:50%;left:50%;padding:2px; z-index: 1000;">
            <img src='../assets/img/demo_wait.gif' width="64" height="64" />
            <br>Loading...
        </div>
        <!-- begin #sidebar -->
        <div id="sidebar" class="sidebar">
            <!-- begin sidebar scrollbar -->
            <!-- begin sidebar user -->
            <!-- end sidebar user -->
            <!-- begin sidebar nav -->
            <?php include("CLMSidePanel.php") ?>
        </div>
        <!-- end #sidebar -->
        <!-- begin #content -->

        <script>
        function LoadInvoiceNo() {

            var InvoiceNo = new Date().getTime();
            document.getElementById("txtInvoiceNo").value = InvoiceNo;

            LoadTimeSlotDetails();

        }

        function SaveTimeSlot() {
         
            var DoctorCode = document.getElementById("cmbDoctorCode").value;
            var FromDate = document.getElementById("dtFromDate").value;
            var ToDate = document.getElementById("dtToDate").value;
            var FromTime = document.getElementById("txtFromTime").value;
            
            var ToTime = document.getElementById("txtToTime").value;
            var SlotType = document.getElementById("cmbSlotType").value;
            var Remarks = document.getElementById("txtRemarks").value;
            var InvoiceNo = document.getElementById("txtInvoiceNo").value;

 
            if (ToTime == "" || FromDate == "" || ToDate == "" || FromTime == ""  || SlotType == "" || InvoiceNo == "") {

                swal("Alert!", " Fill All details", "warning");

            } else {

                 
                var datas = "&DoctorCode=" + DoctorCode +  
                "&FromDate=" + FromDate +
                    "&ToDate=" + ToDate +
                    "&FromTime=" + FromTime +
                    "&ToTime=" + ToTime +
                    "&SlotType=" + SlotType +
                    "&Remarks=" + Remarks +
                    "&InvoiceNo=" + InvoiceNo;
 
                $.ajax({
                    url: "Save/SaveTimeSlot.php",
                    method: "POST",
                    data: datas,
                    success: function(data) {
 
                        if (data == 1) {

                            swal("Time slot updated!", "Sucessfully", "success");
                            // swal(data);

                            location.reload();
                        } else {
                            swal("Alert!", data, "warning");
                            LoadTimeSlotDetails();

                        }


                    }
                });
            }

        }


        function Reset() {
            document.getElementById("txtAmount").value = '';
            document.getElementById("txtRemarks").value = '';

            $("#cmbGroup").val('default');
            $(cmbGroup).selectpicker("refresh");

            $("#cmbDoctorCode").val('default');
            $(cmbDoctorCode).selectpicker("refresh");
            document.getElementById("cmbDoctorCode").focus();
            LoadIncomeExpenseList();
        }

        function CalculateShare() {
            LoadDoctorShare();

            var TotalSales = parseInt(document.getElementById("txtTotalSales").value);
            var Profit = parseInt(document.getElementById("txtProfit").value);
            var SharePercent = parseInt(document.getElementById("txtSharePercent").value);
            var CalculationMode = document.getElementById("cmbCalculationMode").value;


            if (CalculationMode == 'Profit') {
                var AmountToPay = parseInt(Profit) * parseInt(SharePercent) / 100;
                document.getElementById("txtAmountToPay").value = Math.round(AmountToPay);
            } else {
                var AmountToPay = parseInt(TotalSales) * parseInt(SharePercent) / 100;
                document.getElementById("txtAmountToPay").value = Math.round(AmountToPay);
            }

        }


        function CalculateSharePercent() {
            LoadDoctorShare();

            var TotalSales = parseInt(document.getElementById("txtTotalSales").value);
            var Profit = parseInt(document.getElementById("txtProfit").value);
            var AmountToPay = parseInt(document.getElementById("txtAmountToPay").value);
            var CalculationMode = document.getElementById("cmbCalculationMode").value;


            if (CalculationMode == 'Profit') {
                var SharePercent = (parseInt(AmountToPay) / parseInt(TotalSales)) * 100;
                document.getElementById("txtSharePercent").value = Math.round(SharePercent);
            } else {
                var SharePercent = (parseInt(AmountToPay) / parseInt(TotalSales)) * 100;
                document.getElementById("txtSharePercent").value = Math.round(SharePercent);
            }

        }



        function LoadDoctorShare() {
            var DoctorCode = document.getElementById("cmbDoctorCode").value;
            var FromDate = document.getElementById("dtFromDate").value;
            var ToDate = document.getElementById("dtToDate").value;
            var ShareType = document.getElementById("cmbShareType").value;

            var datas = "&DoctorCode=" + DoctorCode + "&FromDate=" + FromDate + "&ToDate=" + ToDate + "&ShareType=" +
                ShareType;

            $.ajax({
                url: "Load/LoadDoctorShare.php",
                method: "POST",
                data: datas,
                dataType: "json",
                success: function(data) {


                    if (data[2] == '0') {
                        document.getElementById("txtTotalSales").value = data[0];
                        document.getElementById("txtProfit").value = data[1];
                    } else {
                        swal('Already Paid');
                        document.getElementById("txtTotalSales").value = '';
                        document.getElementById("txtProfit").value = '';
                        document.getElementById("txtAmountToPay").value = '';
                    }

                }
            });
        }

        function LoadTimeSlotDetails() {

            var DoctorCode = document.getElementById("cmbDoctor").value;

            var FromDate = document.getElementById("dtFromDateReport").value;

            var ToDate = document.getElementById("dtToDateReprt").value;

            var datas = "&DoctorCode=" + DoctorCode + "&FromDate=" + FromDate + "&ToDate=" + ToDate;

            $.ajax({
                url: "Load/LoadTimeSlotDetails.php",
                method: "POST",
                data: datas,
                success: function(data) {
                    $('#DivPaymentHistory').html(data);
                }
            });
        }


        function printDiv() {
            var divToPrint = document.getElementById('DivPrint');
            newWin = window.open("");
            newWin.document.write(divToPrint.outerHTML);
            newWin.print();
            newWin.close();
        }
        </script>


        <style>
        .bootstrap-select:not([class*="span"]):not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) {
            width: 320px;
        }
        </style>

        <div id="content" class="content">
            <div class="row">
                <!-- begin col-6 -->
                <div class="col-md-5">
                    <!-- begin panel -->
                    <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                        <div class="panel-heading">

                            <h4 class="panel-title">Doctor Details</h4>
                        </div>
                        <div class="panel-body">
                            <input type='hidden' id='txtInvoiceNo' name='txtInvoiceNo' />
                            <form class="form-horizontal">

                                <div class="form-group">
                                    <label class="col-md-3 control-label"> Doctor</label>
                                    <div class="col-md-6">



                                        <select class="selectpicker" data-show-subtext="true" data-live-search="true"
                                            data-style="btn-white" id='cmbDoctorCode' name='cmbDoctorCode'
                                            style="width: 100px;">

                                            <?php  
                            $sqli = "SELECT doctorcode,doctorname FROM doctormaster WHERE doctorstatus ='Active' ";
                            $result = mysqli_query($connection, $sqli); 
                             while ($row = mysqli_fetch_array($result)) {
                            	# code...
                          
                             echo ' <option value='.$row['doctorcode'].'>'.$row['doctorname'].'</option>';
                              }	
                            ?>
                                        </select>

                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="col-md-3 control-label">Period</label>

                                    <div class="col-md-4">
                                        <input type="date" class="form-control" placeholder="" id='dtFromDate'
                                            name='dtFromDate' />
                                    </div>

                                    <div class="col-md-4">
                                        <input type="date" class="form-control" placeholder="" id='dtToDate'
                                            name='dtToDate' />
                                    </div>


                                </div>

                                <div class="form-group">
                                    <label class="col-md-3 control-label">Time Slot</label>

                                    <div class="col-md-2">AM
                                        <input type="number" class="form-control" placeholder="" id='txtFromTime'
                                            name='txtFromTime' value='6' disabled />
                                    </div>

                                    <div class="col-md-2">PM
                                        <input type="number" class="form-control" placeholder="" id='txtToTime'
                                            name='txtToTime' value='22' disabled />
                                    </div>


                                    <div class="col-md-4">
                                        Slot Type
                                        <select class='form-control' name='cmbSlotType' id='cmbSlotType'>
                                            <option value='60'>1 Hr Slot</option>
                                            <option value='30'>30 Min Slot</option>
                                        </select>
                                    </div>



                                </div>



                                <div class="form-group">
                                    <label class="col-md-3 control-label">Remarks.</label>

                                    <div class="col-md-6">
                                        <textarea id='txtRemarks' name='txtRemarks' row='5'
                                            class="form-control"></textarea>
                                    </div>
                                </div>





                                <div class="form-group">
                                    <label class="col-md-3 control-label"> </label>
                                    <div class="col-md-9">
                                        <input type="button" class="btn btn-sm btn-success" onClick="SaveTimeSlot();"
                                            value='Save'>
                                        <input type="button" class="btn btn-sm btn-warning" onClick="Reset();"
                                            value='Clear'>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- end panel -->
                </div>
                <div class="col-md-7">

                    <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                        <div class="panel-heading">

                            <h4 class="panel-title">Time Slot Details</h4>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">

                                <label class="radio-inline">
                                    From
                                    <input type="date" class='form-control' name="dtFromDateReport"
                                        id='dtFromDateReport' value='<?php echo date('Y-m-d'); ?>' />

                                </label>
                                <label class="radio-inline">
                                    To
                                    <input type="date" class='form-control' name="dtToDateReprt" id='dtToDateReprt'
                                        value='<?php echo date('Y-m-d'); ?>' />

                                </label>
                                <label class="radio-inline">
                                    Doctor
                                    <select class='form-control' id='cmbDoctor' name='cmbDoctor' style="width: 150px;">

                                        <?php  
                            $sqli = "SELECT doctorcode,doctorname FROM doctormaster WHERE doctorstatus ='Active' ";
                            $result = mysqli_query($connection, $sqli); 
                             while ($row = mysqli_fetch_array($result)) {
                            	# code...
                          
                             echo ' <option value='.$row['doctorcode'].'>'.$row['doctorname'].'</option>';
                              }	
                            ?>
                                    </select>

                                </label>
                                <label class="radio-inline">

                                    <a class="btn btn-success  btn-sm" onclick='LoadTimeSlotDetails();'>View</a>

                                    <a class="btn btn-success  btn-sm" onclick="printDiv();"><i
                                            class="fa  fa-print"></i></a>
                                </label>





                            </div>

                            <div data-scrollbar="true" data-height="510px">
                                <ul class="chats">

                                    <div id="DivPaymentHistory"></div>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- end panel -->
                </div>
            </div>

            <!-- end col-12 -->



        </div>

        <!-- end row -->
    </div>

    </div>
    </div>
    </div>

    <!-- end col-10 -->
    </div>



    <!-- end #content -->
    <!-- begin theme-panel -->
    <!-- end theme-panel -->
    <!-- begin scroll to top btn -->
    <a href="javascript:;" class="btn btn-icon btn-circle btn-success btn-scroll-to-top fade" data-click="scroll-top">
        <i class="fa fa-angle-up"></i>
    </a>
    <!-- end scroll to top btn -->
    </div>
    <!-- end page container -->
    <!-- ================== BEGIN BASE JS ================== -->
    <script src="../assets/plugins/jquery/jquery-1.9.1.min.js"></script>
    <script src="../assets/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
    <script src="../assets/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
    <script src="../assets/plugins/bootstrap/js/bootstrap.min.js"></script>

    <!--[if lt IE 9]>
  <script src="../assets/crossbrowserjs/html5shiv.js"></script>
  <script src="../assets/crossbrowserjs/respond.min.js"></script>
  <script src="../assets/crossbrowserjs/excanvas.min.js"></script>
  <![endif]-->
    <script src="../assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="../assets/plugins/jquery-cookie/jquery.cookie.js"></script>
    <script src="../assets/plugins/DataTables/js/jquery.dataTables.js"></script>
    <script src="../assets/plugins/DataTables/js/dataTables.fixedColumns.js"></script>
    <script src="../assets/js/table-manage-fixed-columns.demo.min.js"></script>
    <!-- ================== END BASE JS ================== -->
    <!-- ================== BEGIN PAGE LEVEL JS ================== -->
    <!-- ================== BEGIN PAGE LEVEL JS ================== -->



    <script src="../assets/js/inbox.demo.min.js"></script>
    <script src="../assets/plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js"></script>
    <script src="../assets/plugins/bootstrap-daterangepicker/moment.js"></script>
    <script src="../assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
    <script src="../assets/js/form-plugins.demo.min.js"></script>
    <script src="../assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
    <script src="../assets/plugins/ionRangeSlider/js/ion-rangeSlider/ion.rangeSlider.min.js"></script>
    <script src="../assets/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
    <script src="../assets/plugins/masked-input/masked-input.min.js"></script>
    <script src="../assets/plugins/password-indicator/js/password-indicator.js"></script>
    <script src="../assets/plugins/bootstrap-combobox/js/bootstrap-combobox.js"></script>
    <script src="../assets/plugins/bootstrap-select/bootstrap-select.min.js"></script>
    <script src="../assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
    <script src="../assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput-typeahead.js"></script>
    <script src="../assets/plugins/jquery-tag-it/js/tag-it.min.js"></script>
    <script src="../assets/plugins/select2/dist/js/select2.min.js"></script>
    <script src="../assets/plugins/switchery/switchery.min.js"></script>
    <script src="../assets/plugins/powerange/powerange.min.js"></script>
    <script src="../assets/js/form-slider-switcher.demo.min.js"></script>
    <script src="../assets/plugins/bootstrap-wizard/js/bwizard.js"></script>
    <script src="../assets/js/form-wizards.demo.min.js"></script>
    <script src="..assets/js/form-plugins.demo.min.js"></script>

    <script src="../assets/Custom/masking-input.js" data-autoinit="true"></script>
    <script src="../assets/js/apps.min.js"></script>
    <!-- ================== END PAGE LEVEL JS ================== -->
    <script>
    $(document).ready(function() {
        App.init();
        Inbox.init();
        FormPlugins.init();
        FormSliderSwitcher.init();
        FormWizard.init();
    });
    </script>
</body>
<!-- Mirrored from seantheme.com/color-admin-v1.7/admin/html/email_inbox.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 24 Apr 2015 10:54:42 GMT -->

</html>